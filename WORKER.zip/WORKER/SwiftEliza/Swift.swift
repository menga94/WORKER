import Foundation

struct Worker {
    // A list of introduction sentences for Worker.
    private let introductions = [
        "Ciao. ?",
        
        "Hai dei problemi da espormi?"
    ]
    
    // A list of goodbye sentences for worker.
    
    private let arrivederci = [
        "Arrivederci, buon lavoro!",
        "Arrivederci",
        
        ]
    
    // A list of tuples of the form: (questionRegex, [answer1, answer2, ...])
    // Ordered by increasing generality of the question regexes
    
    private let psychobabble = [
        
        ("worker dove si trova il prodotto con codice 1", [
            "Il prodotto con codice 1 si trova nella zona 'AA', fronte 5, colonna 12, piano 1",
            ]),
        ("worker dove si trova il prodotto con codice 2", [
            "Il prodotto con codice 2 si trova nella zona 'AA', fronte 3, colonna 8, piano 1",
            ]),
        ("worker dove si trova il prodotto con codice 3", [
            "Il prodotto con codice 3 si trova nella zona 'AB', fronte 2, colonna 3, piano 2",
            ]),
        ("worker dove si trova il prodotto con codice 4", [
            "Il prodotto con codice 4 si trova nella zona 'AC', fronte 6, colonna 4, piano 3",
            ]),
        ("worker dove si trova il prodotto con codice 5", [
            "Il prodotto con codice 5 si trova nella zona 'AA', fronte 4, colonna 2, piano 1",
            ]),
        ("worker dove si trova il prodotto con codice 6", [
            "Il prodotto con codice 6 si trova nella zona 'AB', fronte 5, colonna 3, piano 2",
            ]),
        ("worker dove si trova il prodotto con codice 7", [
            "Il prodotto con codice 7 si trova nella zona 'AA', fronte 1, colonna 10, piano 4",
            ]),
        ("worker dove si trova il prodotto con codice 8", [
            "Il prodotto con codice 8 si trova nella zona 'AC', fronte 2, colonna 9, piano 3",
            ]),
        
        //Prodotti assenti
        
        ("worker sono assenti i prodotti con codice (.*)", [
            "Il prodotto con codice %s non esiste",
            ]),
        
        ("worker il prodotto con codice 1 è esaurito, ho un alternativa?", [
            "Un'alternativa del prodotto con codice 1 si trova nella zona 'AA', fronte 3, colonna 12, piano 1",
            ]),
        ("(.*)\\?", [
            "hai altre domande?",
            ])
    ]
    
    // If Worker doesn't understand the question, then it will reply with one of
    // these default responses.
    private let defaultResponses = [
        "Fammi una domanda valida",
        ]
    
    // Statements that indicate the user wants to end the conversation.
    private let quitStatements = [
        "arrivederci",
        "bye",
        "quit",
        "exit",
        ]
    
    // This is a table to reflect words in question fragments inside the response.
    // For example, "I want your jacket" should be reflected to "You want my jacket"
    // in the response.
    private let reflectedWords = [
        "am": "are",
        "was": "were",
        "i": "you",
        "i'd": "you would",
        "i've": "you have",
        "i'll": "you will",
        "my": "your",
        "are": "am",
        "you've": "I have",
        "you'll": "I will",
        "your": "my",
        "yours": "mine",
        "you": "me",
        "me": "you"
    ]
    
    // WorkerHi will return a random greeting from Worker.
    func WorkerHi() -> String {
        return introductions.randChoice()
    }
    
    // WorkerBye will return a random goodbye from Worker.
    func WorkerBye() -> String {
        return arrivederci.randChoice()
    }
    
    // replyTo will construct a reply for a given statement using Worker's rules.
    func replyTo(_ statement: String) -> String {
        // First, preprocess the statement for more effective matching
        var statement = preprocess(statement)
        
        // Then, we check if this is a quit statement
        if quitStatements.contains(statement)  {
            return WorkerBye()
        }
        
        // Next, we try to match the statement to a statement that Worker can
        // recognize, and construct a pre-determined, appropriate response.
        for (pattern, responses) in psychobabble {
            // Apply the regex re to the statement string
            let re = try! NSRegularExpression(pattern: pattern)
            let matches = re.matches(in: statement, range: NSRange(location: 0, length: statement.characters.count))
            
            // If the statement matched any recognizable statements
            if matches.count > 0 {
                // There should only be one match
                let match = matches[0]
                
                // If we matched a regex capturing group in parentheses, get the first one.
                // The matched regex group will match a "fragment" that will form
                // part of the response, for added realism.
                var fragment = ""
                if match.numberOfRanges > 1 {
                    fragment = (statement as NSString).substring(with: match.rangeAt(1))
                    fragment = reflect(fragment)
                }
                
                // Choose a random appropriate response, and format it with the
                // fragment, if needed.
                var response = responses.randChoice()
                response = response.replacingOccurrences(of: "%s", with: fragment)
                return response
            }
        }
        
        // If no patterns were matched, return a default response.
        return defaultResponses.randChoice()
    }
    
    // preprocess will normalization a statement string for better regex matching.
    private func preprocess(_ statement: String) -> String {
        let trimmed = statement.trimmingCharacters(in: .whitespacesAndNewlines)
        let lowercased = trimmed.lowercased()
        return lowercased
    }
    
    // reflect flips a few words in an input fragment (such as "I" -> "you").
    private func reflect(_ fragment: String) -> String {
        var words = fragment.components(separatedBy: " ")
        for (i, word) in words.enumerated() {
            if let reflectedWord = reflectedWords[word] {
                words[i] = reflectedWord
            }
        }
        return words.joined(separator: " ")
    }
}

// Add a randChoice method to Array's, which returns a random element.
extension Array {
    func randChoice() -> Element {
        let index = Int(arc4random_uniform(UInt32(self.count)))
        return self[index]
    }
}
