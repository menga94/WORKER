import Foundation

class Conversation {
    // List of Messages in the conversation
    var messages = [Message]()
    
    // Add welcoming text to open the conversation
    init() {
        messages.append(Message(date: Date(), text: "Ciao, sono Worker.\nEsponi il tuo problema.\n\nCOMANDO PER TROVARE PRODOTTI : worker dove si trova il prodotto con codice\nCOMANDO PER CONTROLLARE SE UN PRODOTTO E' ASSENTE : worker il prodotto con codice 1 è esaurito, ho un alternativa?", type: .answer))
    }
    
    // Add a new question to the conversation
    func add(question: String) {
        messages.append(Message(date: Date(), text: question, type: .question))
    }
    
    // Add a new answer to the conversation
    func add(answer: String) {
        messages.append(Message(date: Date(), text: answer, type: .answer))
    }
}
